---
name: sasha-bridge
description: Drive a live SashaSlides deck — add, replace, goto, and screenshot slides (and edit drawio diagrams) by sending commands through the local bridge server. Use when the user wants to build or edit slides on a connected display/deck in real time.
user_invocable: true
---

# sasha-bridge

Drive a live Sasha Slides display (browser on this machine, or a phone/projector
on the same network) by sending slide commands through the local bridge server.

Use this skill when the user wants to build or edit slides on a connected
display in real time — add a slide, replace the current slide, screenshot a
slide, or read deck state.

## Prerequisites

The bridge server must be running and a display must be connected. Check with:

```bash
.claude/skills/sasha-bridge.sh state
```

If it reports `bridge not reachable`, tell the user to run `python wrapper.py
serve` from the unzipped `sasha-bridge` folder and open the display from the
integration page (<http://localhost:8787/>). If it reports `no display
connected`, the server is up but no browser display is paired yet.

## Commands

The skill forwards to `bridge/wrapper.py`. Write slide HTML to a temp file and
pass it with `--html-file` (slides are self-contained HTML at 1280×720).

```bash
.claude/skills/sasha-bridge.sh add          --html-file /tmp/slide.html      # append + show
.claude/skills/sasha-bridge.sh add          --html-file /tmp/s.html --index 2 # insert at 2
.claude/skills/sasha-bridge.sh replace      --html-file /tmp/slide.html       # replace CURRENT slide
.claude/skills/sasha-bridge.sh replace      --index 0 --html-file /tmp/s.html # replace slide 0
.claude/skills/sasha-bridge.sh goto         --index 3
.claude/skills/sasha-bridge.sh screenshot   --out-dir /tmp/shots              # current slide
.claude/skills/sasha-bridge.sh screenshot   --range 1-5 --out-dir /tmp/shots  # a range
.claude/skills/sasha-bridge.sh screenshot   --indices 1,3 --xml --out-dir /tmp/shots
.claude/skills/sasha-bridge.sh diagrams                                   # list deck diagrams
.claude/skills/sasha-bridge.sh diagrams     --out-dir /tmp/diagrams       # + write each XML to a file
.claude/skills/sasha-bridge.sh get-diagram  --id <ID> --out-xml /tmp/d.xml
.claude/skills/sasha-bridge.sh edit-diagram --id <ID> --xml-file /tmp/d.xml   # update a deck diagram
.claude/skills/sasha-bridge.sh edit-diagram --id "" --xml-file /tmp/new.xml --slide 3 --x .1 --y .15 --w .8 --h .7
.claude/skills/sasha-bridge.sh state
```

Slides are full self-contained 1280×720 HTML documents (own `<head><style>`,
`body{width:1280px;height:720px}`) — not fragments.

Every command prints a JSON result with `ok: true/false`. After `screenshot`,
read the saved PNG(s) to verify what the deck looks like before continuing.

`state` returns `{count, current, skipped:[...]}` — total slides, the current
(1-based) slide, and the 1-based indices of skipped (hidden) slides.

`screenshot` accepts `--index N` / `--indices 1,3,5` / `--range 1-5,8` (1-based;
default = current slide) and writes `slide_NN.png` into `--out-dir`. Each
returned slide reports `{index, skipped, saved}`. Add `--xml` to also fetch each
slide's OpenXML (best-effort, written as `slide_NN.xml`). In the Google Slides
add-on this exports via the user's OAuth. Large replies are chunked over the
WebRTC data channel, so screenshots and multi-slide ranges work on either
transport (Local device is still snappier for very large ranges). Each returned
slide also carries `diagrams: [{id, name}]` — the editable drawio diagrams on
that slide.

### drawio diagrams (collaborate with the user)

In the Google Slides add-on, diagrams are real drawio diagrams embedded in the
deck (a PNG plus an off-canvas XML source box). The user can edit them in the
**Diagrams** panel of the sidebar (visible under both Automatic and Manual), and
you can read/edit the **same** diagrams over the API — so you collaborate on one
shared diagram:

- `diagrams` lists every diagram: `{id, slide, name, box, xml}` where `box` is the
  current frame in normalized `[0,1]` slide coords `{x,y,w,h}`. `--out-dir` writes
  each XML to `diagram_<id>.drawio.xml` and keeps the rest inline.
- `get-diagram --id <ID>` returns one diagram's drawio XML (`--out-xml` to save).
- `edit-diagram --id <ID> --xml-file f.xml` replaces a diagram's XML; the sidebar
  re-renders the PNG and updates the deck. `--id ""` adds a NEW diagram.
  (`screenshot` first to see each slide's `diagrams` and their ids.)

**Placement** (Slides). All coordinates are NORMALIZED `[0,1]` (fraction of the
slide), so they're resolution-independent:
- `--slide N` — which slide a NEW diagram goes on (1-based; default = current).
- `--x --y` — top-left; `--w --h` — size. Omit them and a new diagram is fit to
  ~80% of the slide preserving aspect and centered; an existing one keeps its
  frame unless you pass coords (then it moves/resizes). The reply reports the
  `slide` it landed on. Only the image moves — the off-canvas XML source box below
  the slide is left in place.

The `id` is the diagram's image object id from `diagrams`/`screenshot`. Edits flow
both ways live: a diagram you write appears in the user's panel, and one they edit
shows up on your next `diagrams`/`get-diagram`. Slides-mode diagram editing renders
via the sidebar's own self-hosted drawio (no repo needed); the `edit-diagram
--index N` form instead drives a diagram on the bridge's **display.html** surface
and needs the bridge running from the repo (so `/drawio` is served).

If a deck op fails with `PERMISSION_DENIED` / "server error … reading from
storage", the user's Google Drive/Slides authorization is stale (Apps Script
won't re-prompt on its own). Tell them to click **Reauthorize** in the
SashaSlides sidebar, approve, reload, and retry — `add_slide` now reports this as
`ok:false` instead of a false success.

## Workflow guidance

- After `add`/`replace`, take a `screenshot` and Read it to confirm the render
  looks right before moving on.
- Prefer `replace` over delete-then-add when refining a slide already on screen.
- Keep slide HTML self-contained (inline styles); the display's screenshot
  capture is most reliable that way.
- Override the port with `SASHA_BRIDGE_PORT` if the user didn't use the default
  `8787`.
